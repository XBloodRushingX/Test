cp.playbarAssetArr = 
[
	'AudioOff',
	'AudioOn',
	'BackGround',
	'Backward',
	'Color',
	'ColorSmall',
	'CC',
	'Exit',
	'FastForward',
	'FastForward1',
	'FastForward2',
	'Forward',
	'Glow',
	'GlowSmall',
	'Height',
	'InnerStroke',
	'InnerStrokeSmall',
	'Play',
	'Pause',
	'Progress',
	'Rewind',
	'Shade',
	'ShadeSmall',
	'Stroke',
	'StrokeSmall',
	'Thumb',
	'ThumbBase',
	'TOC'
];
cp.playbarTooltips = 
{
	AudioOff : "Audio an ",
	AudioOn : "Audio aus ",
	Backward : "Zurück ",
	CC : "Bilduntertitel ",
	Exit : "Beenden ",
	FastForward : "Zweifache Vorspulgeschwindigkeit ",
	FastForward1 : "Vierfache Vorspulgeschwindigkeit ",
	FastForward2 : "Normale Geschwindigkeit ",
	Forward : "Weiter ",
	Play : "Abspielen ",
	Pause : "Anhalten ",
	Rewind : "Zurückspulen ",
	TOC : "Inhaltsverzeichnis ",
	Info : "Informationen ",
	Print : "Drucken "
};
cp.handleSpecialForPlaybar = function(playbarConstruct)
{
}